<!DOCTYPE html>
<html>
<head>
	<title>Login System</title>
	<link rel="stylesheet" href="css_file.css?version=27">
</head>
<body>
  <header>
	  <h1 id="heading"><a href="login_page.php" id="head">VIT QUIZ</a></h1>
  </header>
  <body>
	