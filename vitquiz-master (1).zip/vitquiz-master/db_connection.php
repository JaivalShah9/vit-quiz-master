<?php
	
	$connect=mysqli_connect("localhost","root","","dbms_vit_quiz");

?>